import { Application } from '@nativescript/core';
import { initializeFirebase } from './services/firebase';

try {
    initializeFirebase();
} catch (error) {
    console.error('Firebase initialization failed:', error);
}

Application.run({ moduleName: 'app-root' });