import { JournalEntry } from './storage';

export interface MoodTrend {
    average: number;
    trend: 'improving' | 'declining' | 'stable';
    entries: number;
}

export interface TriggerAnalysis {
    trigger: string;
    frequency: number;
    averageMood: number;
}

export class AnalyticsService {
    static analyzeMoodTrend(entries: JournalEntry[], days: number = 7): MoodTrend {
        if (entries.length === 0) {
            return { average: 0, trend: 'stable', entries: 0 };
        }

        const now = new Date();
        const startDate = new Date(now.getTime() - (days * 24 * 60 * 60 * 1000));
        
        const recentEntries = entries.filter(entry => 
            new Date(entry.timestamp) >= startDate
        );

        if (recentEntries.length === 0) {
            return { average: 0, trend: 'stable', entries: 0 };
        }

        const moodSum = recentEntries.reduce((sum, entry) => sum + entry.moodScale, 0);
        const average = moodSum / recentEntries.length;

        // Calculate trend
        const sortedEntries = [...recentEntries].sort((a, b) => 
            new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
        );

        const firstHalf = sortedEntries.slice(0, Math.floor(sortedEntries.length / 2));
        const secondHalf = sortedEntries.slice(Math.floor(sortedEntries.length / 2));

        const firstHalfAvg = firstHalf.reduce((sum, entry) => sum + entry.moodScale, 0) / firstHalf.length;
        const secondHalfAvg = secondHalf.reduce((sum, entry) => sum + entry.moodScale, 0) / secondHalf.length;

        let trend: 'improving' | 'declining' | 'stable';
        const difference = secondHalfAvg - firstHalfAvg;
        
        if (difference > 0.5) {
            trend = 'improving';
        } else if (difference < -0.5) {
            trend = 'declining';
        } else {
            trend = 'stable';
        }

        return {
            average: Math.round(average * 10) / 10,
            trend,
            entries: recentEntries.length
        };
    }

    static analyzeTriggersImpact(entries: JournalEntry[]): TriggerAnalysis[] {
        const triggerMap = new Map<string, { sum: number; count: number }>();

        entries.forEach(entry => {
            if (entry.analysis?.triggers) {
                entry.analysis.triggers.forEach(trigger => {
                    const current = triggerMap.get(trigger) || { sum: 0, count: 0 };
                    triggerMap.set(trigger, {
                        sum: current.sum + entry.moodScale,
                        count: current.count + 1
                    });
                });
            }
        });

        return Array.from(triggerMap.entries())
            .map(([trigger, { sum, count }]) => ({
                trigger,
                frequency: count,
                averageMood: Math.round((sum / count) * 10) / 10
            }))
            .sort((a, b) => b.frequency - a.frequency);
    }

    static getWeeklyStats(entries: JournalEntry[]) {
        const now = new Date();
        const startOfWeek = new Date(now);
        startOfWeek.setDate(now.getDate() - now.getDay());
        startOfWeek.setHours(0, 0, 0, 0);

        const weekEntries = entries.filter(entry => 
            new Date(entry.timestamp) >= startOfWeek
        );

        const dayStats = new Array(7).fill(null).map((_, index) => {
            const date = new Date(startOfWeek);
            date.setDate(date.getDate() + index);
            
            const dayEntries = weekEntries.filter(entry => 
                new Date(entry.timestamp).getDate() === date.getDate()
            );

            return {
                date,
                entries: dayEntries.length,
                averageMood: dayEntries.length > 0
                    ? dayEntries.reduce((sum, entry) => sum + entry.moodScale, 0) / dayEntries.length
                    : 0
            };
        });

        return dayStats;
    }
}