import { ApplicationSettings } from '@nativescript/core';

export interface JournalEntry {
    id: string;
    text: string;
    moodScale: number;
    timestamp: string;
    analysis: {
        sentiment: string;
        triggers: string[];
        summary: string;
    } | null;
}

const JOURNAL_ENTRIES_KEY = 'journal_entries';
const MAX_ENTRIES = 1000; // Prevent memory issues with too many entries

export class StorageService {
    static getEntries(): JournalEntry[] {
        try {
            const entriesJson = ApplicationSettings.getString(JOURNAL_ENTRIES_KEY);
            return entriesJson ? JSON.parse(entriesJson) : [];
        } catch (error) {
            console.error('Error reading entries:', error);
            return [];
        }
    }

    static saveEntry(entry: Omit<JournalEntry, 'id'>): JournalEntry {
        try {
            const entries = this.getEntries();
            const newEntry = {
                ...entry,
                id: new Date().getTime().toString()
            };
            
            entries.unshift(newEntry);
            
            // Limit the number of stored entries
            if (entries.length > MAX_ENTRIES) {
                entries.length = MAX_ENTRIES;
            }
            
            ApplicationSettings.setString(JOURNAL_ENTRIES_KEY, JSON.stringify(entries));
            return newEntry;
        } catch (error) {
            console.error('Error saving entry:', error);
            throw new Error('Failed to save entry');
        }
    }

    static deleteEntry(id: string): void {
        try {
            const entries = this.getEntries();
            const updatedEntries = entries.filter(entry => entry.id !== id);
            ApplicationSettings.setString(JOURNAL_ENTRIES_KEY, JSON.stringify(updatedEntries));
        } catch (error) {
            console.error('Error deleting entry:', error);
            throw new Error('Failed to delete entry');
        }
    }

    static updateEntry(id: string, updates: Partial<Omit<JournalEntry, 'id'>>): JournalEntry {
        try {
            const entries = this.getEntries();
            const entryIndex = entries.findIndex(e => e.id === id);
            
            if (entryIndex === -1) {
                throw new Error('Entry not found');
            }

            const updatedEntry = {
                ...entries[entryIndex],
                ...updates
            };

            entries[entryIndex] = updatedEntry;
            ApplicationSettings.setString(JOURNAL_ENTRIES_KEY, JSON.stringify(entries));
            
            return updatedEntry;
        } catch (error) {
            console.error('Error updating entry:', error);
            throw new Error('Failed to update entry');
        }
    }

    static clearAllEntries(): void {
        try {
            ApplicationSettings.remove(JOURNAL_ENTRIES_KEY);
        } catch (error) {
            console.error('Error clearing entries:', error);
            throw new Error('Failed to clear entries');
        }
    }

    static getEntriesByDateRange(startDate: Date, endDate: Date): JournalEntry[] {
        try {
            return this.getEntries().filter(entry => {
                const entryDate = new Date(entry.timestamp);
                return entryDate >= startDate && entryDate <= endDate;
            });
        } catch (error) {
            console.error('Error getting entries by date range:', error);
            return [];
        }
    }
}