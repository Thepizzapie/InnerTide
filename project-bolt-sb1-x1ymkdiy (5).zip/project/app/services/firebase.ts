import { firebase } from '@nativescript/firebase-core';
import '@nativescript/firebase-auth';

export function initializeFirebase() {
    firebase().initializeApp();
}