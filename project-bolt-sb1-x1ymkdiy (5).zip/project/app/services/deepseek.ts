import { Http } from '@nativescript/core';

export interface JournalAnalysis {
    sentiment: string;
    triggers: string[];
    summary: string;
}

const API_KEY = 'sk-6fb4f209930f463c8578d9e468929f3d';
const API_URL = 'https://api.deepseek.com/v1/chat/completions';
const RETRY_ATTEMPTS = 3;
const RETRY_DELAY = 1000;

async function delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
}

export async function analyzeJournalEntry(
    text: string, 
    moodScale: number,
    detailedAnalysis: boolean = false
): Promise<JournalAnalysis> {
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= RETRY_ATTEMPTS; attempt++) {
        try {
            const systemPrompt = detailedAnalysis ? 
                `You are an empathetic AI therapist specialized in providing deeper insights and reflections on journal entries.
                 Focus on:
                 - Understanding underlying emotions and patterns
                 - Offering constructive perspectives
                 - Suggesting healthy coping strategies
                 - Identifying growth opportunities
                 
                 Keep responses compassionate, insightful, and actionable.
                 Avoid clinical terminology unless necessary.
                 Always maintain a supportive and non-judgmental tone.` :
                `You are an AI assistant specialized in analyzing journal entries.
                 Provide concise responses for emotions and triggers.
                 
                 ### Emotions:
                 List 2-3 core emotions (brief, comma-separated)
                 Example: "hopeful, self-doubt, stress"
                 
                 ### Key Insights:
                 A concise summary (max 2 sentences)
                 
                 ### Triggers:
                 List 2-3 key triggers (brief, comma-separated)
                 Example: "work pressure, family conflict"
                 ---
                 Keep all responses brief and focused.`;

            const response = await Http.request({
                url: API_URL,
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                },
                content: JSON.stringify({
                    model: 'deepseek-chat',
                    messages: [
                        {
                            role: 'system',
                            content: systemPrompt
                        },
                        {
                            role: 'user',
                            content: `${text} (Mood Scale: ${moodScale}/5)`
                        }
                    ]
                }),
                timeout: 10000
            });

            if (response.statusCode === 200) {
                const data = JSON.parse(response.content);
                const aiResponse = data.choices[0].message.content;
                return detailedAnalysis ? 
                    {
                        sentiment: '',
                        triggers: [],
                        summary: aiResponse
                    } :
                    parseAIResponse(aiResponse);
            }

            throw new Error(`API request failed with status ${response.statusCode}`);
        } catch (error) {
            lastError = error as Error;
            if (attempt < RETRY_ATTEMPTS) {
                await delay(RETRY_DELAY * attempt);
                continue;
            }
        }
    }

    console.error('Failed to analyze entry after retries:', lastError);
    return performLocalAnalysis(text, moodScale);
}

function parseAIResponse(content: string): JournalAnalysis {
    try {
        const sections = {
            emotions: extractSection(content, '### Emotions:'),
            insights: extractSection(content, '### Key Insights:'),
            triggers: extractSection(content, '### Triggers:')
        };

        const emotions = sections.emotions
            .split(',')
            .map(e => e.trim())
            .filter(e => e.length > 0 && e !== 'N/A' && !e.startsWith('###'));

        const triggersList = sections.triggers
            .split(',')
            .map(t => t.trim())
            .filter(t => t.length > 0 && t !== 'N/A' && !t.startsWith('###'));

        return {
            sentiment: emotions.join(', '),
            summary: sections.insights || 'No insights available',
            triggers: triggersList
        };
    } catch (error) {
        console.error('Error parsing AI response:', error);
        return {
            sentiment: 'Error analyzing sentiment',
            summary: 'Failed to analyze entry',
            triggers: []
        };
    }
}

function extractSection(content: string, sectionTitle: string): string {
    try {
        const startIndex = content.indexOf(sectionTitle);
        if (startIndex === -1) return '';

        const start = startIndex + sectionTitle.length;
        const nextSection = content.indexOf('###', start);
        const endMarker = content.indexOf('---', start);
        
        let endIndex = content.length;
        if (nextSection !== -1) endIndex = nextSection;
        if (endMarker !== -1 && endMarker < endIndex) endIndex = endMarker;

        return content.substring(start, endIndex).trim();
    } catch (error) {
        console.error('Error extracting section:', error);
        return '';
    }
}

function performLocalAnalysis(text: string, moodScale: number): JournalAnalysis {
    let emotions: string[];
    if (moodScale <= 2) {
        emotions = ['feeling down', 'anxious'];
    } else if (moodScale >= 4) {
        emotions = ['uplifted', 'at peace'];
    } else {
        emotions = ['balanced', 'reflective'];
    }

    const words = text.toLowerCase().split(/\W+/).filter(word => word.length > 3);
    const wordFrequency = new Map<string, number>();
    
    words.forEach(word => {
        if (!commonWords.has(word)) {
            wordFrequency.set(word, (wordFrequency.get(word) || 0) + 1);
        }
    });

    const triggers = Array.from(wordFrequency.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 2)
        .map(([word]) => word);

    return {
        sentiment: emotions.join(', '),
        triggers,
        summary: `Entry reflects ${emotions[0]} state with ${triggers.length} key themes identified.`
    };
}

const commonWords = new Set([
    'this', 'that', 'these', 'those', 'have', 'were', 'would', 'could', 'should',
    'their', 'there', 'about', 'which', 'when', 'what', 'with', 'from', 'will',
    'they', 'them', 'then', 'than', 'some', 'your', 'been', 'being', 'into'
]);