import { Observable } from '@nativescript/core';

export class ResourcesViewModel extends Observable {
    constructor() {
        super();
    }
}