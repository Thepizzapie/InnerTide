import { NavigatedData, Page } from '@nativescript/core';
import { ResourcesViewModel } from './resources-view-model';

export function onNavigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    page.bindingContext = new ResourcesViewModel();
}

export function onBackButtonTap(args: NavigatedData) {
    const page = <Page>args.object;
    page.frame.goBack();
}