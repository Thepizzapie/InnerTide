import { Observable } from '@nativescript/core';

export class MeditationViewModel extends Observable {
    constructor() {
        super();
    }
}