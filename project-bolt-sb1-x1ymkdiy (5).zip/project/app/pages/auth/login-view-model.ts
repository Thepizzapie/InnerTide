import { Observable, Frame } from '@nativescript/core';

export class LoginViewModel extends Observable {
    private _email: string = '';
    private _password: string = '';

    constructor() {
        super();
    }

    get email(): string {
        return this._email;
    }

    set email(value: string) {
        if (this._email !== value) {
            this._email = value;
            this.notifyPropertyChange('email', value);
        }
    }

    get password(): string {
        return this._password;
    }

    set password(value: string) {
        if (this._password !== value) {
            this._password = value;
            this.notifyPropertyChange('password', value);
        }
    }

    login() {
        if (!this._email || !this._password) {
            alert({
                title: "Error",
                message: "Please enter both email and password",
                okButtonText: "OK"
            });
            return;
        }

        const frame = Frame.topmost();
        if (frame) {
            frame.navigate({
                moduleName: "pages/main/main-page",
                clearHistory: true
            });
        }
    }

    signInWithGoogle() {
        console.log("Google sign in");
        this.login();
    }

    signInWithApple() {
        console.log("Apple sign in");
        this.login();
    }
}