import { Observable, Frame } from '@nativescript/core';
import { StorageService } from '../../services/storage';
import { AnalyticsService } from '../../services/analytics';

export class MainViewModel extends Observable {
    private _username: string = 'User';
    private _currentDate: string = new Date().toLocaleDateString('en-US', { 
        weekday: 'long',
        month: 'long', 
        day: 'numeric' 
    });
    private _recentEntries: any[] = [];
    private _todayMoodEmoji: string = '😊';
    private _weeklyMoodEmoji: string = '😊';

    constructor() {
        super();
        this.loadEntries();
        this.updateMoodIndicators();
    }

    get username(): string {
        return this._username;
    }

    get currentDate(): string {
        return this._currentDate;
    }

    get recentEntries(): any[] {
        return this._recentEntries;
    }

    get todayMoodEmoji(): string {
        return this._todayMoodEmoji;
    }

    get weeklyMoodEmoji(): string {
        return this._weeklyMoodEmoji;
    }

    loadEntries() {
        const entries = StorageService.getEntries()
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        
        this._recentEntries = entries.map(entry => ({
            ...entry,
            moodEmoji: this.moodToEmoji(entry.moodScale),
            dateLabel: this.formatDetailDate(entry.timestamp),
            timeLabel: this.formatTime(entry.timestamp),
            title: entry.text
        }));
        
        this.notifyPropertyChange('recentEntries', this._recentEntries);
    }

    private formatDetailDate(timestamp: string): string {
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        });
    }

    private updateMoodIndicators() {
        const entries = StorageService.getEntries();
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Today's mood
        const todayEntry = entries.find(entry => {
            const entryDate = new Date(entry.timestamp);
            return entryDate >= today;
        });
        
        if (todayEntry) {
            this._todayMoodEmoji = this.moodToEmoji(todayEntry.moodScale);
            this.notifyPropertyChange('todayMoodEmoji', this._todayMoodEmoji);
        }

        // Weekly average
        const weeklyTrend = AnalyticsService.analyzeMoodTrend(entries, 7);
        this._weeklyMoodEmoji = this.moodToEmoji(weeklyTrend.average);
        this.notifyPropertyChange('weeklyMoodEmoji', this._weeklyMoodEmoji);
    }

    newEntry() {
        const frame = Frame.topmost();
        if (frame) {
            frame.navigate({
                moduleName: "pages/journal/journal-entry-page",
                clearHistory: false
            });
        }
    }

    showInsights() {
        const frame = Frame.topmost();
        if (frame) {
            frame.navigate("pages/insights/insights-page");
        }
    }

    showReflection() {
        const frame = Frame.topmost();
        if (frame) {
            frame.navigate("pages/reflection/reflection-page");
        }
    }

    showResources() {
        const frame = Frame.topmost();
        if (frame) {
            frame.navigate("pages/resources/resources-page");
        }
    }

    onEntryTap(args: any) {
        const entry = this._recentEntries[args.index];
        const frame = Frame.topmost();
        if (frame) {
            frame.navigate({
                moduleName: "pages/journal/journal-detail-page",
                context: entry
            });
        }
    }

    private moodToEmoji(scale: number): string {
        const emojis = ['😢', '😔', '😐', '😊', '🥰'];
        const index = Math.min(Math.max(Math.floor(scale) - 1, 0), emojis.length - 1);
        return emojis[index];
    }

    private formatTime(timestamp: string): string {
        return new Date(timestamp).toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
    }
}