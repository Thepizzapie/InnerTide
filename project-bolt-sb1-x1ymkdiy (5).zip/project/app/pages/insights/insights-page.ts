import { EventData, Page } from '@nativescript/core';

export function onNavigatingTo(args: EventData) {
    const page = <Page>args.object;
}

export function onBackButtonTap(args: EventData) {
    const page = <Page>args.object;
    if (page.frame) {
        page.frame.goBack();
    }
}