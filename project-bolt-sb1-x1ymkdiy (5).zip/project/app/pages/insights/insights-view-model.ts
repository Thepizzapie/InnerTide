import { Observable } from '@nativescript/core';

export class InsightsViewModel extends Observable {
    constructor() {
        super();
    }
}