import { Observable, Frame, NavigatedData } from '@nativescript/core';
import { StorageService, JournalEntry } from '../../services/storage';
import { analyzeJournalEntry } from '../../services/deepseek';

interface Message {
    text: string;
    isAI: boolean;
}

export class ReflectionViewModel extends Observable {
    private _selectedEntry: JournalEntry | null = null;
    private _messages: Message[] = [];
    private _userInput: string = '';

    constructor() {
        super();
    }

    get selectedEntry(): JournalEntry | null {
        return this._selectedEntry;
    }

    set selectedEntry(value: JournalEntry | null) {
        if (this._selectedEntry !== value) {
            this._selectedEntry = value;
            this.notifyPropertyChange('selectedEntry', value);
            
            if (value) {
                // Add initial AI message
                this.addMessage({
                    text: "I've analyzed your journal entry. What would you like to explore? You can ask about:\n\n" +
                          "• Deeper emotional patterns\n" +
                          "• Alternative perspectives\n" +
                          "• Coping strategies\n" +
                          "• Personal growth opportunities",
                    isAI: true
                });
            } else {
                this._messages = [];
                this.notifyPropertyChange('messages', this._messages);
            }
        }
    }

    get messages(): Message[] {
        return this._messages;
    }

    get userInput(): string {
        return this._userInput;
    }

    set userInput(value: string) {
        if (this._userInput !== value) {
            this._userInput = value;
            this.notifyPropertyChange('userInput', value);
        }
    }

    selectEntry() {
        const entries = StorageService.getEntries()
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

        const frame = Frame.topmost();
        if (frame) {
            frame.showModal("pages/reflection/select-entry-modal", {
                context: {
                    entries,
                    callback: (selectedEntry: JournalEntry) => {
                        this.selectedEntry = selectedEntry;
                    }
                },
                fullscreen: true
            });
        }
    }

    async sendMessage() {
        if (!this._userInput.trim() || !this._selectedEntry) return;

        // Add user message
        this.addMessage({
            text: this._userInput,
            isAI: false
        });

        const userQuestion = this._userInput;
        this.userInput = ''; // Clear input

        try {
            // Get AI response
            const response = await this.getAIResponse(userQuestion);
            
            // Add AI response
            this.addMessage({
                text: response,
                isAI: true
            });
        } catch (error) {
            console.error('Error getting AI response:', error);
            this.addMessage({
                text: "I apologize, but I'm having trouble processing your request. Please try again.",
                isAI: true
            });
        }
    }

    private addMessage(message: Message) {
        this._messages.push(message);
        this.notifyPropertyChange('messages', this._messages);
    }

    private async getAIResponse(userQuestion: string): Promise<string> {
        if (!this._selectedEntry) return "No entry selected";

        const analysis = await analyzeJournalEntry(
            `Question: ${userQuestion}\n\nJournal Entry: ${this._selectedEntry.text}`,
            this._selectedEntry.moodScale,
            true // Enable detailed analysis mode
        );

        return analysis.summary;
    }
}