import { EventData, Page } from '@nativescript/core';
import { ReflectionViewModel } from './reflection-view-model';

export function onNavigatingTo(args: EventData) {
    const page = <Page>args.object;
    page.bindingContext = new ReflectionViewModel();
}

export function onBackButtonTap(args: EventData) {
    const page = <Page>args.object;
    if (page.frame) {
        page.frame.goBack();
    }
}