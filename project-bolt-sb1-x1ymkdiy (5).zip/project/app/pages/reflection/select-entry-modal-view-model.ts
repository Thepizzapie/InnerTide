import { Observable, Page } from '@nativescript/core';
import { JournalEntry } from '../../services/storage';

export class SelectEntryModalViewModel extends Observable {
    private _entries: JournalEntry[];
    private _callback: (entry: JournalEntry) => void;
    private _page: Page;

    constructor(page: Page) {
        super();
        this._page = page;
        const modalContext = page.navigationContext;
        this._entries = modalContext.entries;
        this._callback = modalContext.callback;
    }

    get entries(): JournalEntry[] {
        return this._entries;
    }

    onEntrySelect(args: any) {
        const selectedEntry = this._entries[args.index];
        this._callback(selectedEntry);
        this._page.closeModal();
    }

    moodToEmoji(scale: number): string {
        const emojis = ['😢', '😔', '😐', '😊', '🥰'];
        const index = Math.min(Math.max(Math.floor(scale) - 1, 0), emojis.length - 1);
        return emojis[index];
    }

    formatDate(timestamp: string): string {
        return new Date(timestamp).toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric'
        });
    }
}