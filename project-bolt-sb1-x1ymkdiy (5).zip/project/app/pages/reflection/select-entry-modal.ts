import { EventData, Page, View } from '@nativescript/core';
import { SelectEntryModalViewModel } from './select-entry-modal-view-model';

export function onNavigatingTo(args: EventData) {
    const page = <Page>args.object;
    page.bindingContext = new SelectEntryModalViewModel(page);
}

export function onClose(args: EventData) {
    const view = <View>args.object;
    const page = view.page;
    page?.closeModal();
}