import { Observable, Frame, alert } from '@nativescript/core';
import { analyzeJournalEntry, JournalAnalysis } from '../../services/deepseek';
import { StorageService } from '../../services/storage';

export class JournalEntryViewModel extends Observable {
    private _journalText: string = '';
    private _moodScale: number = 3;
    private _isSaving: boolean = false;
    private _analysis: JournalAnalysis | null = null;

    constructor() {
        super();
    }

    get journalText(): string {
        return this._journalText;
    }

    set journalText(value: string) {
        if (this._journalText !== value) {
            this._journalText = value;
            this.notifyPropertyChange('journalText', value);
        }
    }

    get moodScale(): number {
        return this._moodScale;
    }

    set moodScale(value: number) {
        if (this._moodScale !== value) {
            this._moodScale = value;
            this.notifyPropertyChange('moodScale', value);
        }
    }

    get isSaving(): boolean {
        return this._isSaving;
    }

    set isSaving(value: boolean) {
        if (this._isSaving !== value) {
            this._isSaving = value;
            this.notifyPropertyChange('isSaving', value);
        }
    }

    get analysis(): JournalAnalysis | null {
        return this._analysis;
    }

    set analysis(value: JournalAnalysis | null) {
        if (this._analysis !== value) {
            this._analysis = value;
            this.notifyPropertyChange('analysis', value);
        }
    }

    moodToEmoji(scale: number): string {
        const emojis = ['😢', '😔', '😐', '😊', '🥰'];
        const index = Math.min(Math.max(Math.floor(scale) - 1, 0), emojis.length - 1);
        return emojis[index];
    }

    async saveEntry() {
        if (!this.journalText.trim()) {
            alert({
                title: "Empty Entry",
                message: "Please write something before saving.",
                okButtonText: "OK"
            });
            return;
        }

        this.isSaving = true;
        
        try {
            // Get AI analysis
            this.analysis = await analyzeJournalEntry(this.journalText, this.moodScale);
            
            // Save entry with analysis
            StorageService.saveEntry({
                text: this.journalText,
                moodScale: this.moodScale,
                timestamp: new Date().toISOString(),
                analysis: this.analysis
            });

            // Show analysis for 2 seconds before going back
            setTimeout(() => {
                const frame = Frame.topmost();
                if (frame) {
                    frame.goBack();
                }
            }, 2000);
        } catch (error) {
            console.error('Error saving entry:', error);
            alert({
                title: "Error",
                message: "Failed to save your entry. Please try again.",
                okButtonText: "OK"
            });
        } finally {
            this.isSaving = false;
        }
    }
}