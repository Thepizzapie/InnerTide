import { NavigatedData, Page } from '@nativescript/core';
import { JournalDetailViewModel } from './journal-detail-view-model';
import { JournalEntry } from '../../services/storage';

export function onNavigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    const entry = args.context as JournalEntry;
    
    if (!entry) {
        console.error('No entry data provided');
        if (page.frame) {
            page.frame.goBack();
        }
        return;
    }

    page.bindingContext = new JournalDetailViewModel(entry);
}

export function onBackButtonTap(args: NavigatedData) {
    const page = <Page>args.object;
    if (page.frame) {
        page.frame.goBack();
    }
}