import { Observable } from '@nativescript/core';
import { JournalEntry } from '../../services/storage';

export class JournalDetailViewModel extends Observable {
    private _entryDate: string;
    private _entryText: string;
    private _moodEmoji: string;
    private _triggers: string[] = [];
    private _emotionsList: string[] = [];

    constructor(entry: JournalEntry) {
        super();
        
        // Format the date
        const date = new Date(entry.timestamp);
        this._entryDate = date.toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        });

        // Set the entry text
        this._entryText = entry.text;

        // Set mood emoji
        this._moodEmoji = this.moodToEmoji(entry.moodScale);

        // Set triggers
        if (entry.analysis?.triggers) {
            this._triggers = entry.analysis.triggers;
        }

        // Set emotions
        if (entry.analysis?.sentiment) {
            this._emotionsList = entry.analysis.sentiment.split(',').map(e => e.trim());
        }
    }

    get entryDate(): string {
        return this._entryDate;
    }

    get entryText(): string {
        return this._entryText;
    }

    get moodEmoji(): string {
        return this._moodEmoji;
    }

    get triggers(): string[] {
        return this._triggers;
    }

    get emotionsList(): string[] {
        return this._emotionsList;
    }

    get hasTriggers(): boolean {
        return this._triggers.length > 0;
    }

    get hasEmotions(): boolean {
        return this._emotionsList.length > 0;
    }

    private moodToEmoji(scale: number): string {
        const emojis = ['😢', '😔', '😐', '😊', '🥰'];
        const index = Math.min(Math.max(Math.floor(scale) - 1, 0), emojis.length - 1);
        return emojis[index];
    }
}