import { NavigatedData, Page } from '@nativescript/core';
import { JournalEntryViewModel } from './journal-entry-view-model';

export function onNavigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    if (!page.bindingContext) {
        page.bindingContext = new JournalEntryViewModel();
    }
}

export function onBackButtonTap(args: NavigatedData) {
    const page = <Page>args.object;
    if (page.frame) {
        page.frame.goBack();
    }
}